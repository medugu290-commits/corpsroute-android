# CorpsRoute Nigeria — update 1.1

This is an updated Android WebView project for CorpsRoute Nigeria. The update focuses on the agreed PCM travel-planning purpose and deliberately excludes live-location sharing/tracking.

## Included in this starter update
- State selection for all 36 Nigerian states and the FCT.
- Journey outline from state of origin to state of deployment, with optional arrival town and PPA destination.
- User-entered transport budget calculator, rather than unverified automatic fare claims.
- General NYSC preparation checklist and link to the official NYSC website.
- Motor-park verification suggestion form and verification guidance.
- PPA information search and suggestion form.
- Reserved, clearly labelled sponsored space.

## Important limitations
- This is a UI/prototype update. It does not connect to a backend or central database.
- Motor-park and PPA submissions are prepared as text files on the device; they are not sent to an administrator.
- No motor parks are claimed to be verified in this build.
- There is no live verified fare feed. Users enter quotes they receive, and the app totals them.
- The state explorer is a selectable state list, not a detailed geographic state-boundary map yet.
- Live-location tracking is intentionally excluded and location permissions have been removed.
- Camp venue and packing requirements must be confirmed against current official NYSC instructions.

## Build
The GitHub Actions workflow in `.github/workflows/build-apk.yml` builds a signed release APK using the repository's signing secrets. Keep the existing signing key and secrets if you want this APK to update the already-installed app. Increment `versionCode` for each subsequent Android release.

## Update 1.2 — Nearby services
Added a Nearby Services screen with seven map-search categories: Motor Park, Hospital, Pharmacy, Hotel, Restaurant, ATM and Police Station. Users enter a town/address/landmark or choose a state, then open a Google Maps search. This does not use device live location and does not imply that Google Maps results have been verified by CorpsRoute. Listings must be checked by the user before relying on them.
