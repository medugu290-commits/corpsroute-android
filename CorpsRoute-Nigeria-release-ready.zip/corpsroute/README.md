# CorpsRoute Nigeria

This project builds a signed release APK for Android.

GitHub Actions workflow: `.github/workflows/build-apk.yml`

Required GitHub Actions secrets:
- `SIGNING_KEY` = Base64 contents of the permanent release keystore
- `KEY_STORE_PASSWORD` = keystore password
- `KEY_ALIAS` = key alias
- `KEY_PASSWORD` = key password

The release APK is uploaded as the `CorpsRoute-Nigeria-release` workflow artifact.
