# CorpsRoute Nigeria

Android app for NYSC camp discovery, PPA guidance, transport estimates, GPS and nearby services.

## Build
The GitHub Actions workflow installs Gradle 8.7 and builds the debug APK with Android Gradle Plugin 8.6.1 and JDK 17.

APK output: `app/build/outputs/apk/debug/app-debug.apk`
