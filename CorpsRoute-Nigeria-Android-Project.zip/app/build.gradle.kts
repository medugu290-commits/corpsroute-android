plugins {
    id("com.android.application")
}

android {
    namespace = "ng.corpsroute.nigeria"
    compileSdk = 35

    defaultConfig {
        applicationId = "ng.corpsroute.nigeria"
        minSdk = 24
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
        }
    }
}

dependencies {
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("androidx.webkit:webkit:1.12.1")
}
